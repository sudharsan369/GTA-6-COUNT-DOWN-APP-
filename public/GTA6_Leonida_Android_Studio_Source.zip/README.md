# GTA 6 Countdown Flutter & Android Project
Run `flutter build apk --release` to build the release APK.
